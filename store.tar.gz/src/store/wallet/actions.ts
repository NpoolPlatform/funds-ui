enum apipath {
  GetBalance = '/sphinx-proxy/v1/get/balance',
  CreateWallet = '/sphinx-proxy/v1/create/wallet',
  CreateTransaction = '/sphinx-proxy/v1/create/transaction',
  GetTransaction = '/sphinx-proxy/v1/get/transaction'
}
