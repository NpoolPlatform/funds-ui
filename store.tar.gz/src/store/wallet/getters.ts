import { GetterTree } from 'vuex'
import { StateInterface } from '../index'
import { WalletState, BalanceInfo } from './state'

type Getters = {
  getError (state: WalletState): string;
  getLoading (state: WalletState): boolean;
  getAddress (state: WalletState): string;
  getBalance (state: WalletState): BalanceInfo;
}

export const getters: GetterTree<WalletState, StateInterface> & Getters = {
  getError: (state: WalletState) => state.error,
  getLoading: (state: WalletState) => state.loading,
  getAddress: (state: WalletState) => state.Address,
  getBalance: (state: WalletState): BalanceInfo => {
    return {
      Balance: state.Balance,
      BalanceStr: state.BalanceStr
    }
  }
}

export default getters
