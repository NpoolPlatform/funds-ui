import { Module } from 'vuex'
import { StateInterface } from '../index'
import { WalletState } from './state'
// import actions from './actions'
import getters from './getters'
import mutations from './mutations'

const wallet: Module<WalletState, StateInterface> = {
  namespaced: true,
  // actions,
  getters,
  mutations
}

export default wallet
