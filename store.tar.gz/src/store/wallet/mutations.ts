import { MutationTree } from 'vuex'
import { MutationTypes } from './mutation-types'
import { WalletState } from './state'

type Mutations<S = WalletState> = {
  [MutationTypes.SET_ERROR] (state: S, payload: string): void;
  [MutationTypes.SET_LOADING] (state: S, payload: boolean): void;

  [MutationTypes.SET_ADDRESS] (state: S, payload: string): void;
  [MutationTypes.SET_BALANCE] (state: S, payload: number): void;

  [MutationTypes.SET_NAME] (state: WalletState, payload: string): void;
  [MutationTypes.SET_FROM] (state: WalletState, payload: string): void;
  [MutationTypes.SET_TO] (state: WalletState, payload: string): void;
  [MutationTypes.SET_AMOUNT] (state: WalletState, payload: number): void;
}

const mutations: MutationTree<WalletState> & Mutations = {
  [MutationTypes.SET_ERROR] (state: WalletState, payload: string) {
    state.error = payload
  },
  [MutationTypes.SET_LOADING] (state: WalletState, payload: boolean) {
    state.loading = payload
  },

  [MutationTypes.SET_ADDRESS] (state: WalletState, payload: string) {
    state.Address = payload
  },
  [MutationTypes.SET_BALANCE] (state: WalletState, payload: number) {
    state.Balance = payload
  },
  [MutationTypes.SET_NAME] (state: WalletState, payload: string) {
    state.Name = payload
  },
  [MutationTypes.SET_FROM] (state: WalletState, payload: string) {
    state.From = payload
  },
  [MutationTypes.SET_TO] (state: WalletState, payload: string) {
    state.To = payload
  },
  [MutationTypes.SET_AMOUNT] (state: WalletState, payload: number) {
    state.Amount = payload
  }
}

export default mutations
